package com.example.util;
//军队线程
// 模拟作战双方的行为
public class ArmyRunnable implements Runnable {
	// volatile 保证了当前线程可以正确读取其他线程写入的值
	// 可见性 happens-before 原则
    volatile Boolean keepRunning = true;
	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(keepRunning) {
			//发动5次进攻
			for(int i=0;i<5;i++) {
				System.out.println(Thread.currentThread().getName()+"进攻对方"+ (i+1)+"次");
				// 让出处理器的处理时间
				Thread.yield();
			}
		}
		System.out.println(Thread.currentThread().getName()+"结束了战斗");
	}

}
