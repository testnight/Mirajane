package com.example.task;
/****
 * 定时任务
 */
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
//定义组件 component 注解
@Component
public class TestTask {

	private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	// 定义每过3秒执行任务
    @Scheduled(fixedRate = 3000)
//	@Scheduled(cron = "0 0 15 * * ?")
    public void reportCurrentTime() {
    	System.out.println("******************************************");
        System.out.println("现在时间：" + dateFormat.format(new Date()));
        System.out.println("******************************************");
    }
}
