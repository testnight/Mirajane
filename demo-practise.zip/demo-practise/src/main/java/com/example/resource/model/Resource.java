package com.example.resource.model;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
//引用资源文件配置 该注解
@ConfigurationProperties(prefix="com.imooc.opensource")
//属性资源位置 打包后放在classpath下
@PropertySource(value="classpath:resource.properties")
public class Resource {
private String name;
private String website;
private String language;
private String add;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getWebsite() {
	return website;
}
public void setWebsite(String website) {
	this.website = website;
}
public String getLanguage() {
	return language;
}
public void setLanguage(String language) {
	this.language = language;
}
public String getAdd() {
	return add;
}
public void setAdd(String add) {
	this.add = add;
}

}
