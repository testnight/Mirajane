package com.example.exception;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.http.server.ServletServerHttpResponse;
//发生异常会被该类捕获
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.ModelAndView;

import com.example.util.IMoocJSONResult;
//@ControllerAdvice
@RestControllerAdvice
public class IMoocExceptionHandler {
	public static final String ERROR_VIEW = "error";
	@Autowired
	//而不是我们预想的byZero的异常，这时候需要使用MappingJackson2HttpMessageConverter把IMoocJSONResult手动写入 HttpServletResponse中。
	private MappingJackson2HttpMessageConverter jsonConverter;
	
//	@ExceptionHandler(value=Exception.class)
//	public Object errorHandler(HttpServletRequest request,HttpServletResponse response,Exception e) {
//		ModelAndView mav = new ModelAndView();
//		mav.addObject("exception", e);
//		mav.addObject("url",request.getRequestURL());
//		mav.setViewName(ERROR_VIEW);
//		return mav;
//	}
	@ExceptionHandler(value = Exception.class)
    public Object errorHandler(HttpServletRequest reqest, 
    		HttpServletResponse response, Exception e) throws Exception {
    	
    	e.printStackTrace();
    	
    	if (isAjax(reqest)) {
    
    		jsonConverter.write(IMoocJSONResult.errorException(e.getMessage()), MediaType.APPLICATION_JSON, new ServletServerHttpResponse(response));
    		return null;
    	} else {
    		ModelAndView mav = new ModelAndView();
            mav.addObject("exception", e);
            mav.addObject("url", reqest.getRequestURL());
            mav.setViewName(ERROR_VIEW);
            return mav;
    	}
    }
	//判断请求类型
	public static boolean isAjax(HttpServletRequest httpRequest){
		return  (httpRequest.getHeader("X-Requested-With") != null  
					&& "XMLHttpRequest"
						.equals( httpRequest.getHeader("X-Requested-With").toString()) );
	}
}
