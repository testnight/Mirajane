package com.example.mapper;

import java.util.List;

import com.example.model.SysUser;


public interface SysUserMapperCustom {
	
	List<SysUser> queryUserSimplyInfoById(String id);
}