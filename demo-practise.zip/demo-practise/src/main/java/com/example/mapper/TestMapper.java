package com.example.mapper;

import com.example.model.Test;
import com.example.util.MyMapper;

public interface TestMapper extends MyMapper<Test> {
}