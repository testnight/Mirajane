package com.example.interview;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;

public class InterViewSettle {
	/******
	 * 统计元素出现个数
	 */
	public static void calculate() {
		
		String[] arr= {"a","a","b","b","b","c","c","c"};
		Map<String,Integer> hs = new HashMap<String,Integer>();
		
		for(int i = 0;i<arr.length; i++) {
			Integer sum = hs.get(arr[i]);
			hs.put(arr[i], sum == null ? 1: sum+1);
		}
		
//		System.out.println(hs.keySet());
//		System.out.println(hs.values());
		for (Map.Entry<String,Integer> string : hs.entrySet()) {
			System.out.println("元素"+string.getKey() +"的个数为:"+string.getValue());
		}
		for(String key:hs.keySet()) {
			System.out.print("元素："+key+"的个数为："+hs.get(key));
		}
	}
	
	/***
	 * 线程池
	 * @param as
	 */
	@SuppressWarnings("unused")
	public static void ExecutoSrerviceT() {
		//创建固定大小的线程池
		ExecutorService fPool = Executors.newFixedThreadPool(2);
		//创建缓存大小的线程池
		ExecutorService cPool = Executors.newCachedThreadPool();
		 //创建单一的线程池
		ExecutorService sPool = Executors.newSingleThreadExecutor();
        long start = System.currentTimeMillis();
		Thread t1 = new MyThread();
		Thread t2 = new MyThread();
		Thread t3 = new MyThread();
		Thread t4 = new MyThread();
		Thread t5 = new MyThread();
		fPool.execute(t1);
		fPool.execute(t2);
		fPool.execute(t3);
		fPool.execute(t4);
		fPool.execute(t5);
		long end = System.currentTimeMillis();
		long between = end - start;
		System.out.println(between);
		//关闭线程池
		fPool.shutdown();
	}
	
	/*****
	 * 多线程计算数组和
	 * @param as
	 */
	public static void ConcurrentCalculator() {
	  
	  List<Future<Long>> futurelistTasks = new ArrayList<Future<Long>>();
	  SumCalculate sc = new SumCalculate();
	  FutureTask<Long> futuretask = new FutureTask<Long>(sc);
	  futurelistTasks.add(futuretask);
		
	}
	public static void main(String[] as) {
		//InterViewSettle.calculate();
		//InterViewSettle.ExecutoSrerviceT();
		InterViewSettle.ConcurrentCalculator();
	}
}
