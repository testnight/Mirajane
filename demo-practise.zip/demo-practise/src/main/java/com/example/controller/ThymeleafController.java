package com.example.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.model.Role;
import com.example.model.User;
import com.example.resource.model.Resource;
//使用改注解 不使用restcontroller 配置问题
@Controller
@RequestMapping("ths")
public class ThymeleafController {
	//自动注入
	@Autowired
	private Resource resource;
	
	@RequestMapping("/index")
	public String index(ModelMap map) {
		//相当于modelandview
		map.put("name", "mimi");
		return "thymeleaf/index";
	}
	
	@RequestMapping("/center")
	public String center(ModelMap map) {
		map.put("desc", "描述");
		map.put("resource", resource);
		return "thymeleaf/center/center";
	}
	
	@RequestMapping("/test")
	public String test(ModelMap map) {
		User user = new User();
		User u1 = new User();
		User u2 = new User();
		user.setAge(18);
		u1 = user;
		u2 = user;
		user.setName("lee");
		user.setBirthday(new Date());
		user.setDesc("<span style='color:red;font-size:20px;'>描述文件</span>");
		map.put("user", user);
		List<User> userList = new ArrayList<>();
		userList.add(user);
		userList.add(u1);
		userList.add(u2);
		
		map.addAttribute("userList", userList);
		List keyvalList = new ArrayList();
		Role hs =new Role();
		hs.setId("1");
		hs.setName("qiqi");
		keyvalList.add(hs);
		
		Role hss =new Role();
		hss.setId("2");
		hss.setName("haha");
		keyvalList.add(hss);
		
		map.addAttribute("roleList", keyvalList);
		return "thymeleaf/test";
	}
	@RequestMapping("postform")
	public String postform(User user) {
		System.out.print(user.getName());
		System.out.print(user.getAge());
		System.out.print(user.getDesc());
		return "thymeleaf/center/user";
	}
}
