package com.example.interview;

import java.util.concurrent.Callable;

public class SumCalculate implements Callable<Long> {
	
	private int[] numbers;
	private int start;
	private int end;

	public SumCalculate() {
		System.out.println("Callable starting ");
	}

	public SumCalculate(int[] arr, int start, int end) {
		this.numbers = arr;
		this.start = start;
		this.end = end;
	}

	@Override
	public Long call() throws Exception {

		long sum = 0l;
		for (int j = start; j < end; j++) {
			sum = sum + numbers[j];
		}
		return sum;
	}

}
