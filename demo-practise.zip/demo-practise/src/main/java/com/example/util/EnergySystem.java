package com.example.util;
/***
 * 宇宙的能两系统
 * 能量不会凭空产生，也不会消失
 * 只会从一处转到另一处
 * @author Cyistal
 *
 */
public class EnergySystem {
	private final double[] energyBoxes;
	private final Object lockobj = new Object();
/**
 * 	
 * @param n
 * @param initialEnergy
 */
 public EnergySystem(int n,double initialEnergy) {
	 energyBoxes = new double[n];
	 for(int i=0;i<energyBoxes.length;i++) {
		 energyBoxes[i] = initialEnergy;
	 }
 }
 /***
  * 能量转移
  */
 public void transfer(int from,int to,double amount) {
	 synchronized (lockobj) {
		 // while 循环保证调教不满足是被条件阻断
		 // 而不是继续竞争CPU 资源
		 // wait set 锁对象中
		 while(energyBoxes[from]<amount) {
			 try {
				 lockobj.wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 }
		 System.out.println(Thread.currentThread().getName());
		 energyBoxes[from] = energyBoxes[from]-amount;
		 System.out.printf("从%d转移%.2f单位能量到%d",from,amount,to);
		 energyBoxes[to] = energyBoxes[to]+amount;
		 System.out.printf("能量总和：%10.2f%n",getTotalEnergies());
		 // 唤醒所有等待线程
		 lockobj.notifyAll();
	}
	
 }
 /***
  * 能量总和
  */
 public double getTotalEnergies() {
	 double sum = 0;
	 for(int i=0;i<energyBoxes.length;i++) {
		 sum+=energyBoxes[i];
	 }
	 return sum;
 }
 /***
  * 返回盒子长度
  */
 public int getBoxAmount() {
	 return energyBoxes.length;
 }
}
