package com.example.util;

public class Actor extends Thread {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println(getName()+"是一个演员！");
		int count= 0;
		while(true) {
			System.out.println(getName()+"演出"+ (++count)+"次");
			if(count % 10 ==0) {
				break;
			}
		}
		
		System.out.println(getName()+"演出结束了");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread actor = new Actor();
		actor.setName("Mr.Thread");
		actor.start();
		Thread actressRunnable = new Thread(new Actress(),"Ms.Runnable");
		//actressRunnable.setName("Ms.Runnable");
		actressRunnable.start();
	}
}
class Actress implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println(Thread.currentThread().getName()+"是一个演员！");
		int count= 0;
		while(true) {
			System.out.println(Thread.currentThread().getName()+"演出"+ (++count)+"次");
			if(count % 10 ==0) {
				break;
			}
		}
		
		System.out.println(Thread.currentThread().getName()+"演出结束了");
	}
}

