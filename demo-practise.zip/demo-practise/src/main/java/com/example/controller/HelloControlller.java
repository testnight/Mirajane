package com.example.controller;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.resource.model.Resource;
import com.example.util.IMoocJSONResult;

@RestController
public class HelloControlller {
	@Autowired
	private Resource resource;
	
	@RequestMapping("/helloResource")
	public String helloResource() {
		return "hello resource";
	}
	
	@RequestMapping("getResource")
	public IMoocJSONResult getReource() {
		Resource bean = new Resource();
		//利用反射机制 处理相同属性之间的赋值，没有对应属性 则不处理
		BeanUtils.copyProperties(resource, bean);
		return IMoocJSONResult.ok(bean);
	}
}
