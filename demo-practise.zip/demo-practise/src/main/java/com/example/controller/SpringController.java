package com.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
//没有写controller mapping 就可以直接访问 否则需要 加上该mapping
//@RequestMapping("hello")
@Controller
//@RestController 等同于 resonsebody + controller 注解 之和
public class SpringController {
	
	@ResponseBody
	@RequestMapping("hellos")
	public String hello(){
		return "ad";
	}
	
	@ResponseBody
	@RequestMapping("helloworld")
	public String helloworld(){
		return "helloworld";
	}
	@ResponseBody
	@RequestMapping("hhh")
	public String hhhh(){
		return "hellowoddddddrld";
	}
	
	@RequestMapping("rest")
	public String rest(){
		return "hellowoddddddrld";
	}
}
