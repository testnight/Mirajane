package com.example.mapper;

import com.example.model.SysUser;
import com.example.util.MyMapper;

public interface SysUserMapper extends MyMapper<SysUser> {
}