package com.example.util;

public class EnergyTransferTask implements Runnable {
	private EnergySystem energySystem;
	private int fromBox;
	private double maxAmount;
	private int DELAY=10;
	volatile boolean flag = false;
	EnergyTransferTask(EnergySystem energySystem,int fromBox,double maxAmount){
		this.energySystem = energySystem;
		this.fromBox = fromBox;
		this.maxAmount = maxAmount;
	}
	@Override
	public void run() {
		try {
			while(flag) {
				int toBox = (int)(energySystem.getBoxAmount()*Math.random());
				double amount = maxAmount*Math.random();
				energySystem.transfer(fromBox, toBox, amount);
				Thread.sleep((int)(DELAY*Math.random()));
			}
		}catch(Exception e) {
			
		}

	}

}
