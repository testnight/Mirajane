package com.example.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.thymeleaf.util.StringUtils;

import com.example.mapper.SysUserMapper;
import com.example.mapper.SysUserMapperCustom;
import com.example.model.SysUser;
import com.example.service.UserService;
import com.github.pagehelper.PageHelper;

import tk.mybatis.mapper.entity.Example;
@Service
public class UserServiceImpl implements UserService{
@Autowired
private SysUserMapper userMapper;
//自动注入 自定义sql mapper
@Autowired
private SysUserMapperCustom sysUserMapperCustom;
	@Override
	public void saveUser(SysUser user) {
		// TODO Auto-generated method stub
		userMapper.insert(user);
	}

	@Override
	public void updateUser(SysUser user) {
		// TODO Auto-generated method stub
		userMapper.updateByPrimaryKeySelective(user);
	}

	@Override
	public void deleteUser(String userId) {
		// TODO Auto-generated method stub
		userMapper.deleteByPrimaryKey(userId);
	}

	@Override
	public SysUser queryUserById(String userId) {
		// TODO Auto-generated method stub
		
		return userMapper.selectByPrimaryKey(userId);
	}

	@Override
	public List<SysUser> queryUserList(SysUser user) {
		// TODO Auto-generated method stub
		return userMapper.select(user);
	}

	@Override
	@Transactional(propagation = Propagation.SUPPORTS)
	//如当前有transaction，则在transaction状态下执行；如果当前没有transaction，在无transaction状态下执行；
	public List<SysUser> queryUserListPaged(SysUser user, Integer page, Integer pageSize) {
		// 开始分页
        PageHelper.startPage(page, pageSize);
		
		Example example = new Example(SysUser.class);
		Example.Criteria criteria = example.createCriteria();
		
		if (!StringUtils.isEmptyOrWhitespace(user.getNickname())) {
			criteria.andLike("nickname", "%" + user.getNickname() + "%");
		}
		example.orderBy("registTime").desc();
		List<SysUser> userList = userMapper.selectByExample(example);
		
		return userList;
	}
	@Transactional(propagation = Propagation.SUPPORTS)
	//对于操作如果有事务最好，将当前操作添加进去 没有的话 则在没有事务的情况下执行
	@Override
	public SysUser queryUserByIdCustom(String userId) {
		// TODO Auto-generated method stub
		List<SysUser> userList = sysUserMapperCustom.queryUserSimplyInfoById(userId);
		if (userList != null && !userList.isEmpty()) {
			return userList.get(0);
		}
		return null;
	}

	@Override
	//增加 删除 修改 执行操作时，如果有事务 那么添加进去，没有事务的话 则创建出一个
	@Transactional(propagation = Propagation.REQUIRED)
	public void saveUserTransactional(SysUser user) {
		// TODO Auto-generated method stub
		//此处事务将会回滚
		userMapper.insert(user);
		int a = 1/0;
		user.setIsDelete(1);
		userMapper.updateByPrimaryKeySelective(user);
	}

}
