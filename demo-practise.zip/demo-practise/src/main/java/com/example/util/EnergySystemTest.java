package com.example.util;

public class EnergySystemTest {
	// 构建能量盒子数量
	public final static int BOX_AMOUNT = 100;
	public final static double INITIAL_ENERGY = 1000;
	public static void main(String[] args) {
		EnergySystem energySystem = new EnergySystem(BOX_AMOUNT,INITIAL_ENERGY);
		for(int i=0;i<BOX_AMOUNT;i++) {
			System.out.println("当前处理盒子"+i);
			EnergyTransferTask energyTransferTask = new EnergyTransferTask(energySystem, i, INITIAL_ENERGY) ;
			energyTransferTask.flag = true;
			Thread t = new Thread(energyTransferTask);
			t.start();
		}
		
	}
}
