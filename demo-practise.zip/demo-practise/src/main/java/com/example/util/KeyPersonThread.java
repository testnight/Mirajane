package com.example.util;

public class KeyPersonThread extends Thread {

	@Override
	public void run() {
		System.out.println(getName()+"开始加入战斗");
		for(int i=0;i<10;i++) {
			System.out.println(getName()+"开始战斗"+(i+1)+"次");
		}
		System.out.println(getName()+"结束战斗");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
