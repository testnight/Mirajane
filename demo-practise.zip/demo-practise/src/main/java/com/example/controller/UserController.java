package com.example.controller;

import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.model.User;
import com.example.util.IMoocJSONResult;
//没有写controller mapping 就可以直接访问 否则需要 加上该mapping
//@RequestMapping("userController")
@Controller
//@RestController 等同于 resonsebody + controller 注解 之和
public class UserController {
	
	@ResponseBody
	@RequestMapping("getUser")
	public User getUser() {
		User u = new User();
		u.setName("imooc");
		u.setBirthday(new Date());
		u.setAge(52);
		u.setDesc("starting");
		return u;
	}
	@ResponseBody
	@RequestMapping("getUserJson")
	public IMoocJSONResult getUserJson() {
		User u = new User();
		u.setName("imooc");
		u.setBirthday(new Date());
		u.setAge(52);
		u.setDesc("starting");
		return IMoocJSONResult.ok(u);
	}
}
