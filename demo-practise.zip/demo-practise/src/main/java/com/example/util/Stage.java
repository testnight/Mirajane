package com.example.util;

public class Stage extends Thread {

	@Override
	public void run() {
		System.out.println("楷书了,安静都");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		System.out.println("拉开蓄谋");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		ArmyRunnable a = new ArmyRunnable();
		ArmyRunnable b = new ArmyRunnable();
		// 创建线程
		Thread armySui = new Thread(a,"随军");
		Thread armyRev = new Thread(b,"农民");
		// 启动线程
		armySui.start();
		armyRev.start();
		
		// 舞台线程休眠 大家观看斯杀
		try {
			Thread.sleep(50);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		a.keepRunning = false;
		b.keepRunning = false;
		try {
			armyRev.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("程咬金出厂啦");
		Thread mrCheng = new KeyPersonThread();
		mrCheng.setName("程咬金");
		System.out.println("程咬金离线就是想结束战争");
		// 军队停止 
		a.keepRunning = false;
		b.keepRunning = false;
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//历史人物开始战斗
		mrCheng.start();
		try {
			//所有线程等待当前进程完成
			mrCheng.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("结束结束");
		System.out.println("结束纾解");
	}
	public static void main(String []args) {
		new Stage().start();
	}
	
}
