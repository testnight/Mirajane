package com.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.util.IMoocJSONResult;

@Controller

//@RequestMapping("err")
public class ErrorController {
	//测试访问页面时 后台服务发生异常的情况
	@RequestMapping("/errors")
	public String nomalerrors(){
		int a = 1 / 0;
		System.out.println(a);
		return "thymeleaf/error";
	}
	//测试访问页面时 ajax 调用后台服务发生异常的情况
	@RequestMapping("/ajaxerror")
	public String ajaxerror() {
		
		return "thymeleaf/ajaxerror";
	}
	
	@RequestMapping("/getAjaxerror")
	@ResponseBody
	public IMoocJSONResult getAjaxerror() {
		int a = 1 / 0;
		return IMoocJSONResult.ok();
	}
}